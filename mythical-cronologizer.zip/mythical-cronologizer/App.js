import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableHighlight,
  TextInput,
  Image,
} from 'react-native';
import { f, auth, database, storage } from './config/config.js';
import { createAppContainer } from 'react-navigation';
import { createBottomTabNavigator } from 'react-navigation-tabs';

import feed from './screens/feed.js';
import upload from './screens/upload.js';
import profile from './screens/profile.js';

const TabNavigator = createBottomTabNavigator(
  {
    Feed: { screen: feed },
    Upload: { screen: upload },
    Profile: { screen: profile },
  },
  {
    defaultNavigationOptions: ({ navigation }) => ({
      tabBarIcon: () => {
        const routeName = navigation.state.routeName;
        console.log(routeName);
        if (routeName === 'Feed') {
          return (
            <Image
              source={require('./assets/lobby.png')}
              style={{ width: 40, height: 40 }}
            />
          );
        } else if (routeName === 'Upload') {
          return (
            <Image
              source={require('./assets/upload.png')}
              style={{ width: 40, height: 40 }}
            />
          );
        } else if (routeName === 'Profile') {
          return (
            <Image
              source={require('./assets/profile.png')}
              style={{ width: 40, height: 40 }}
            />
          );
        }
      },
    }),
  }
);

export default class App extends React.Component {
  render() {
    return <AppContainer />;
  }
}

const AppContainer = createAppContainer(TabNavigator);

///////////////////////////////////////////////////Functions////////////////////////////////

/*constructor(props)
  {
    super(props);
    this.state = {
      loggedin: false
    }
    //this.registerUser('xyz@gmail.com', 'password')
 
 
    var that =this;
    f.auth().onAuthStateChanged(function(user) {
      if(user){
        //Logged in
        that.setState({
          loggedin: true
        });
        console.log('Logged in', user);
      }else{
        //Logged out
        that.setState({
          loggedin: false
      });
      console.log('Logged out');
      }
    });
  }

  loginUser = async(email,pass) => {

    if(email != '' && pass != ''){
      //
      try{
        let user = await auth.signInWithEmailAndPassword(email,pass)
        console.log(user);
      } catch(error){
        console.log(error);
      }
    }else{
      //If they are empty
      alert('Missing email or possword')
    }

  }

  registerUser = (email, password) => {

    console.log(email, password);
    auth.createUserWithEmailAndPassword(email, password)
    .then((user) => console.log(email, password, userObj))
    .catch((error) => console.log('Error Logging in', error));

  }

  signUserOut = () => {
    auth.signOut()
    .then(()=>{
      console.log('Logged out.');
    }).catch((error)=> {
      console.log('Error:', error);
    })
  }*/

/////////////////////////////////////////Interface/////////////////////////

/*<View style={styles.container}>
        <Text>Welcome to Mythical Cronologizer!</Text>
        <Text>-----</Text>
        { this.state.loggedin == true ? (
          <View>
            <TouchableHighlight
            onPress={ () => this.signUserOut()}
            style={{backgroundColor: 'red'}}>
              <Text>Log Out</Text>
            </TouchableHighlight>
            <Text>Logged in ....</Text>
          </View>
        ) : (
          <View>

              <TouchableHighlight
              onPress={() => this.setState({emailloginView: true})}
              style={{backgroundColor: 'green'}}>
              <Text style={{color: 'white'}}>Login With Email</Text>
              </TouchableHighlight>

            {this.state.emailloginView == true ? (
              
              <View>
                <Text>Email:</Text>
                <TextInput
                  onChangeText={(text) => this.setState({email: text})}
                  value={this.state.email}
                />

                <Text>Password:</Text>
                <TextInput
                onChangeText={(text)=> this.setState({pass: text})}
                secureTextEntry={true}
                value={this.state.pass}
                />

                <TouchableHighlight
                  onPress={ () => this.loginUser(this.state.email,this.state.pass)}
                  style={{backgroundColor: 'red'}}>
                  <Text>Login</Text>
                </TouchableHighlight>

              </View>
            ):(
              <View></View>
            )}                       
          
            

         
            
          </View>
        )}
  </View>*/

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
