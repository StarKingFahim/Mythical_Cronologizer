import firebase from 'firebase';

//Api Details

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const config = {
  apiKey: "AIzaSyBjsEn7qU0xb6Z8KW3Itbmsjjqd16mJzFY",
  authDomain: "mythical-cronologizer.firebaseapp.com",
  projectId: "mythical-cronologizer",
  storageBucket: "mythical-cronologizer.appspot.com",
  messagingSenderId: "400735595881",
  appId: "1:400735595881:web:b7750e6b27ffe7a5b8e1f8",
  measurementId: "G-VRZKZGDYG1"
};


firebase.initializeApp(config)

export const f= firebase;
export const database = firebase.database();
export const auth = firebase.auth();
export const storage = firebase.storage();